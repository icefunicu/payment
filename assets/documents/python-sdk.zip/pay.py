#!/usr/bin/python
# -*- coding: UTF-8 -*-

import requests
import random
import hashlib

headers={
    'User-Agent':'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Mobile Safari/537.36'
}
url='http://127.0.0.1:7856/gateway/order'

# 商户签名KEY
key = "4HzHe7hPWxhRtrGJJWFYi8Zh"

# 传输内容
content = {
    'version' : "v20",        #接口版本
    'pid' : "zBhEMr5BXM",     #商户编号
    'trade_no' : ''.join(random.sample('zyxwvutsrqponmlkjihgfedcba',19)),  #订单号   
    'trade_money': "25.0",    #支付金额
    'action' : "SN20104",     #渠道编码
    'notify_url': "https://domain/notify",    #异步回调地址
    'return_url' : "https://domain/callback", #同步回调地址

    'bankcode' :"",
    'uid' : "",
    'title' : "",
    'service' : "",
    'args' : "",

    'sign' :""
}

# 签名
md5 = content['pid'] + content['trade_no']+content['notify_url'] +content['return_url']+content['action']+content['bankcode']+content['uid']+content['trade_money'] + '&' + key
hl = hashlib.md5()
hl.update(md5.encode("utf-8"))
content['sign'] = hl.hexdigest()
#post 提交
response = requests.post(url=url,data=content,headers=headers) 
ctx = response.text
 
print(ctx)

# 正常的回传参数
# {"success":true,"code":0,"request":{"url":"http://127.0.0.1:7856/pay/KP6958934241841375976271","type":"get"}}