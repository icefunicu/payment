#!/usr/bin/python
# -*- coding: UTF-8 -*-

import requests
import random
import hashlib

# 您的签名KEY
key = "4HzHe7hPWxhRtrGJJWFYi8Zh"
# 回调参数 [不同框架获取惨稍有不同,可根据如下代码适当修改]
content = {
    'status' : "200",                           # 订单状态
    'order' : "bgcxtqhelskaupfzioy",            # 商户订单号
    'money' : '25',                             # 金额
    'paytime': "20250202020",                   # 支付时间
    'type' : "notify",                          # 回调类型
    'uid': "",                                  # 用户账号
    'time' : "",                                # 回调时间戳
    'sign' : ""
}

# 签名
md5 = content['order']+'=' + content['time']+'='+content['money']+'=' +content['type']+'='+content['uid']+'='+content['paytime']+'='+content['status']+'='+'#KEY=' + key
hl = hashlib.md5()
hl.update(md5.encode("utf-8"))
mysign = hl.hexdigest()

# 验证签名
if(mysign == content['sign']):
    print('成功')
else:
    print('失败')