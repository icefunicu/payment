<?php
# 您的签名KEY
$key = "4HzHe7hPWxhRtrGJJWFYi8Zh";

# 必要参数
$version = 'v20';               #接口版本
$pid = "zBhEMr5BXM";            #商户编号
$trade_no = GetRandStr(21);     #订单号   
$trade_money = "0.02";          #支付金额
$action = "SN20104";            #渠道编码

$notify_url = "https://domain/notify";
$return_url = "https://domain/callback";

# 可选参数
$bankcode = "";
$uid = "";
$title = "";
$service = "";
$args = "";

# 签名
$md5 = $pid . $trade_no . $notify_url . $return_url . $action . $bankcode . $uid . $trade_money . '&' . $key;
$sign = md5($md5);

# 请求的数据
$data = array(
    'version' => $version,
    'pid' => $pid,
    'trade_no' => $trade_no,
    'trade_money' => $trade_money,
    'action' => $action,
    'notify_url' => $notify_url,
    'return_url' => $return_url,
    'bankcode' => $bankcode,
    'uid' => $uid,
    'title' => $title,
    'service' => $service,
    'args' => $args,
    'sign' => $sign
);

$data = http_build_query($data);
# 这里使用的是curl,请确认您的扩展是否已开启
$html = httpPost('http://127.0.0.1:7856/gateway/order',$data);
echo $html;

# ******************************************************
function GetRandStr($length)
{
    $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $len = strlen($str) - 1;
    $randstr = '';
    for ($i = 0; $i < $length; $i++) {
        $num = mt_rand(0, $len);
        $randstr .= $str[$num];
    }
    return $randstr;
}
function httpPost($url = '', $param = [])
{
    if (!$url || empty($param))
        return false;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}