<?php

# 您的签名KEY
$key = "4HzHe7hPWxhRtrGJJWFYi8Zh";


$status = $_REQUEST['status'];      #订单状态
$order = $_REQUEST['order'];        #订单号
$money = $_REQUEST['money'];        #交易金额
$paytime = $_REQUEST['paytime'];    #付款时间
$type = $_REQUEST['type'];          #回调类型 callback
$uid = $_REQUEST['uid'];            #用户账号
$time = $_REQUEST['time'];          #回调时间戳
$args = $_REQUEST['args'];          #自定义参数
$sign = $_REQUEST['sign'];          #md5验证签名串
# 签名
$md5 = "order=" . $order . "&time=" . $time . "&money=" . $money . "&type=" . $type . "&uid=" . $uid . "&paytime=" . $paytime . "&status=" . $status . "#KEY=" . $key;
$mysign = md5($md5);
if ($mysign == $sign) {
    #..... 您的代码 (不要进行业务逻辑运算,只展示支付结果即可,以异步通知为准) 
    echo ('充值成功'); #输出成功
} else {
    echo ('签名错误');
}