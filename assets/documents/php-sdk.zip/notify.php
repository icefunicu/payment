<?php

# 您的签名KEY
$key = "4HzHe7hPWxhRtrGJJWFYi8Zh";


$status = $_REQUEST['status'];      #订单状态
$order = $_REQUEST['order'];        #订单号
$money = $_REQUEST['money'];        #交易金额
$paytime = $_REQUEST['paytime'];    #付款时间
$type = $_REQUEST['type'];          #回调类型   notify
$uid = $_REQUEST['uid'];            #用户账号
$time = $_REQUEST['time'];          #回调时间戳
$args = $_REQUEST['args'];          #自定义参数
$sign = $_REQUEST['sign'];          #md5验证签名串
# 签名
$md5 = "order=" . $order . "&time=" . $time . "&money=" . $money . "&type=" . $type . "&uid=" . $uid . "&paytime=" . $paytime . "&status=" . $status . "#KEY=" . $key;
$mysign = md5($md5); 
if ($mysign == $sign) {
    #..... 您的代码 (为用户账户增加积分 延长VIP时间 订单设置为成功状态 等..)
    #..... 无论您是否成功设置订单状态为成功,都应该输出success字符串,以告知我方此次通知是成功的,否则将持续进行通知
    echo ('success'); #输出成功
} else {
    echo ('签名错误');
}