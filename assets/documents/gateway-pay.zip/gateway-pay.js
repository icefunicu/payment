
/**
 * 引用
 * [基本上需要的库都在这里,如没有特殊要求不需要引入其他库]
 * [接口不要引入数据库操作]
 */
const path = require('path');
const http = require(path.resolve('./utils/http'));
const payBase = require(path.resolve('./scripts/gateway/IPayPort'));
const _tool_ = require(path.resolve('./utils/tool'));
var { encode } = require('urlencode');


/**
 * 支付接口
 */
module.exports = {
    /**
     * 接口名称
     * [可以任意填写,但尽量区分出各个上游平台]
     */
    Name: "调试专业接口",
    /**
     * 接口版本
     * [没有太大意义,主要为使用者区分接口是不是需要更新]
     */
    Version: '4.6',
    /**
     * 接口唯一编码
     * [不能与其他接口重复]
     * [这个值在这套系统中必须唯一,不能重复,可以是任意字符]
     */
    Away: 'DEBUG',
    /**
     * 异步通知成功时,返回给上游的信息
     * [根据上游接口文档而定,基本上都是一些字符串,可能区分大小写]
     */
    NotifySuccessMessage: 'success',
    /**
     * 接口描述信息
     * [描述信息不支付特殊字符,基本上用于给使用者更详细的说明]
     */
    Describe: '测试专用接口',
    /**
     * 需要的参数
     * [上游需要传递的参数,如果后期参数有改动,直接修改这些参数即可,然后在系统后台更新接口程序后重新设置参数即可]
     */
    Args: [
        { name: 'postUrl', text: '请求地址', val: 'http://127.0.0.1:7856/run-test/debug' },

        { name: 'merchantId', text: '商户ID', val: '666 可以有默认值,也可以是空字符串,不能是null等 特殊符号' },
        { name: 'signKEY', text: '商户密钥', val: '888' },

        { name: 'notifyUrl', text: '异步通知', val: 'http://127.0.0.1:7856/trade/pay28/notify' },
        { name: 'returnUrl', text: '同步通知', val: 'http://127.0.0.1:7856/trade/pay28/callback' }
    ],
    /**
     * 支持的渠道
     * [一般上游支付多个渠道,在这里进行区分,Gateway:渠道代码 Text:渠道名称]
     * [有些上游情况可能比较特殊,也可以进行自定义,然后在{Build}函数中进行自定义解析]
     */
    Gateways: [
        { Gateway: "weixin.h5pay", Text: "微信h5支付", },
        { Gateway: "weixin.apppay", Text: "微信app支付", },
        { Gateway: "weixin.native", Text: "微信扫码支付", },
        { Gateway: "weixin.jspay", Text: "微信公众号支付", },
        { Gateway: "alipay.h5pay", Text: "支付宝h5支付", },
        { Gateway: "alipay.apppay", Text: "支付宝app支付", },
        { Gateway: "alipay.native", Text: "支付宝扫码支付", }
    ],
    /**
     * 初始化接口
     * [此方法为固定写法,系统自动调用]
     * @param {Arrer} _args 接口需要的参数
     */
    Init: function (_args) {
        this.Args = _args;
    },
    /**
    * 生产表达,用于提交参数
    * @param {String} oid 订单编号
    * @param {Float} money 金额
    * @param {String} title 订单标题
    * @param {String} describe 订单描述
    * @param {String} type 使用的渠道代码[Gateways.Gateway 参数]
    * @param {Request} req 请求体[用于获取其他参数]
    */
    async Build(oid, money, title, describe, type, req) {

        console.pay('参数:', oid, money, title, describe, type)
        let _results = payBase.BuildResults();//这个为固定写法,payBase.BuildResults拥有三个属性 IsSuccess PostType Html
        _results.IsSuccess = true;//是否成功
        /**
         * _results.IsSuccess = true;//是否成功
         * 
         * _results.PostType = 对于值[不同值展示页面不同]
         * payBase.PostType 修改这个参数的值,前台将显示不同的付款界面
         * payBase.PostType.GET 向下游返回支付链接,下游解析这个链接[直接转型这个url地址即可]
         * payBase.PostType.JSON 与GET相似,返回值有一定json数据,需要下游自己解析
         * payBase.PostType.FORM 以post表达的形式进行跳转,实际与GET相同,只是有些上游需要post形式提交,或者某些参数不能通过地址栏传递
         * payBase.PostType.POST 与FORM基本一致
         * payBase.PostType.QRIMG 上游返回二维码地址,直接展示在本系统页面,或者直接返回给下游[如果需要隐藏上游,可也由本系统展示页面]
         * payBase.PostType.QRCODE 上游返回的是二维码数据,本系统自己生产图片并展示
         * payBase.PostType.TRANSFER 向指定账号转账 本系统页面展示
         * 
         * 
         * _results.Html
         * 向下游展示的内容,可以是url链接 也可以是form表单{form表单使用tool.createForm('url提交地址',[{key1:'key1',val1:'val1'},{key2:'key2',val2:'val2'},{key3:'key3',val3:'val3'}],'true/false')}
         * 
         */
        //_results.PostType = payBase.PostType.QRIMG;
        //_results.Html = '生产二维码 手机扫描';

        _results.PostType = payBase.PostType.FORM;
        _results.Html = `<h4>生产接口成功</h4>`;
        _results.Html += `<br/><lable>同步回调测试地址:</lable><a href="${this.Args.find(e => e.name == 'returnUrl').val}?order=${oid}&money=${money}">${this.Args.find(e => e.name == 'returnUrl').val}?order=${oid}&money=${money}</a>`;
        _results.Html += `<br/><lable>异步回调测试地址:</lable><a href="${this.Args.find(e => e.name == 'notifyUrl').val}?order=${oid}&money=${money}">${this.Args.find(e => e.name == 'notifyUrl').val}?order=${oid}&money=${money}</a>`;

        return _results
    },
    /**
    * 验证回调
    * [这里进行参数验证,上游接到付款成功的消息后,由上游调用这个函数,通知本系统]
    * @param {CallBackType} _callBackType 回调类型
    * @param {Request} req 请求体
    * @returns 
    */
    async Validation(_callBackType, req) {

        /**
         * 参数验证后返回如下参数:
         * return{
                Message:'验证 不成功',
                IsSuccess:false,
                CallBackOrder:{
                    Money:200.00,
                    Order:'本系统订单号'
                }
            }
         *  为了代码统一,尽量使用下面形式
         */
        let _results = payBase.CallBackResults();
        _results.IsSuccess = true;
        _results.CallBackOrder.Money = req.query['money'];
        _results.CallBackOrder.Order = req.query['order'];
        _results.Message = "验证成功";



        //此处的 return 为固定写法
        return new Promise((resolve, reject) => {
            resolve(_results);
        })
    }
}